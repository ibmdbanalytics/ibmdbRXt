# 
# Copyright (c) 2010, 2014, IBM Corp. All rights reserved. 
# 		
# This program is free software: you can redistribute it and/or modify 
# it under the terms of the GNU General Public License as published by 
# the Free Software Foundation, either version 3 of the License, or 
# (at your option) any later version. 
#
# This program is distributed in the hope that it will be useful, 
# but WITHOUT ANY WARRANTY; without even the implied warranty of 
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
# GNU General Public License for more details. 
#
# You should have received a copy of the GNU General Public License 
# along with this program. If not, see <http://www.gnu.org/licenses/>. 
#

checkDoubleSpInputs.col <- function (x, y, funcName, argStr=list()) {
  if (!inherits(x,'ida.col.def') || !inherits(y,'ida.col.def')) 
    stop(simpleError(paste(funcName, " can only be applied to columns of ida.data.frame", sep='')))
  if (!idaExistTable(x@table@table)) {
    pos <-   regexpr('$', argStr$x,  fixed=TRUE)
    idfName <- ifelse(pos!=-1, substr(argStr$x, 1, pos-1), '')
    idfName <- ifelse(nchar(idfName)>0, paste("'", idfName, "' ", sep=''), '')
    stop(simpleError(paste(funcName, " failed: the table or view '", x@table@table, 
               "' referred by the input ida.data.frame ", idfName, "does not exist in the database.", sep='')))
  }
  if (!is.sp.col(x)) 
    stop(simpleError(paste(funcName, " failed: the input column '", argStr$x, "' does not contain spatial data.", sep='')))
  if (!is.sp.col(y)) 
    stop(simpleError(paste(funcName, " failed: the input column '", argStr$y, "' dose not contain spatial data.", sep='')))
  if (x@table@table != y@table@table)
    stop(simpleError(paste(funcName, " failed: the input columns are not in the same ida.data.frame.", sep='')))
}

doubleSpColFunc.col <- function (x, y, funcName, spName, argStr) {
  checkDoubleSpInputs.col(x, y, funcName, argStr)
  return(new(Class="ida.col.def", term=paste(spName, '(', x@term, ', ', y@term, ')', sep=''),
             table=x@table, type="expr", aggType="none"));
}

checkDoubleSpInputs.tab <- function(x, y, by.x, by.y, funcName, argStr=list()) {
  if(!is.ida.data.frame(x))
    stop(simpleError(paste(funcName, " failed: the input '", argStr$x, "' is not a ida.data.frame object.", sep='')))
  if(!is.ida.data.frame(y))
    stop(simpleError(paste(funcName, " failed: the input '", argStr$y, "' is not a ida.data.frame object.", sep='')))
  if (!idaExistTable(x@table))
    stop(simpleError(paste(funcName, " failed: the table or view '", x@table, "' referred by the ida.data.frame '", argStr$x,  
                           "' does not exist in the database.", sep='')))
  if (!idaExistTable(y@table))
    stop(simpleError(paste(funcName, " failed: the table or view '", y@table, "' referred by the ida.data.frame '", argStr$y,  
                           "' does not exist in the database.", sep='')))
  if (is.null(by.x))
    stop(simpleError(paste(funcName, " failed: no spatial column was found in the input ida.data.frame '", 
                           argStr$x, "'.", sep='')))
  if (is.null(by.y)) 
    stop(simpleError(paste(funcName, " failed: no spatial column was found in the input ida.data.frame '", 
                           argStr$y, "'.", sep='')))
  if (!is.sp.col(by.x))
    stop(simpleError(paste(funcName, " failed: the input column '", argStr$by.x, "' does not contain spatial data.", sep='')))
  if (!is.sp.col(by.y))
    stop(simpleError(paste(funcName, " failed: the input column '", argStr$by.y, "' does not contain spatial data.", sep='')))
  if (x@table != by.x@table@table)
    stop(simpleError(paste(funcName, 
         " failed: the column '", argStr$by.x, "' specified by the parameter 'by.x' is not in the ida.data.frame '", argStr$x, 
         "' specified by the parameter 'x'.", sep='')))
  if (y@table != by.y@table@table)
    stop(simpleError(paste(funcName, 
         " failed: the column '", argStr$by.y, "' specified by the parameter 'by.y' is not in the ida.data.frame '", argStr$y, 
         "' specified by the parameter 'y'.", sep='')))
#  if (normalizeDBName(x@table) == normalizeDBName(y@table))
#    stop(simpleError(paste(funcName, 
#        " failed: the input ida.data.frame '", argStr$x,"' and '", argStr$y, "' both refer to the same table or view '", x@table, "'", sep='')))
}

validateTabName <- function(tableName) {
  if(is.null(tableName)) {
    tableName <- idaGetValidTableName();
  }
  else if(idaExistTable(tableName)) {
    stop("Table already exists, choose different name.") 
  }
  tableName = ibmdbR:::parseTableName(tableName)$table;
  return(tableName)
}

resolveNameConflict <- function(x, y, by.x, by.y) {
  xColNames <- x@cols
  yColNames <- y@cols
  clash <- intersect(xColNames, yColNames)
  xTabName <- ibmdbR:::parseTableName(x@table)
  yTabName <- ibmdbR:::parseTableName(y@table)
  if(xTabName$table != yTabName$table) {
    xTabName <- xTabName$table
    yTabName <- yTabName$table
  }
  else if (xTabName$schema != yTabName$schema) {
    xTabName <- xTabName$schema
    yTabName <- yTabName$schema
  }
  else {
    xTabName <- 'X'
    yTabName <- 'Y'
  }

  by_x_name <- ibmdbR:::colName(by.x);
  by_y_name <- ibmdbR:::colName(by.y);
  # ida.data.frame might have more than one spatial columns  
  xSpColNames <- spatial.cols(x, TRUE, FALSE)
  ySpColNames <- spatial.cols(y, TRUE, FALSE)
  if (length(clash)>0) { 
    # maximum length of the column name in DB2 is 30
    maxLength <- max(nchar(clash))+1
    if (maxLength+nchar(xTabName)<=30 && maxLength+nchar(yTabName)<=30) {
      xColPrefix <- xTabName
      yColPrefix <- yTabName
    }
    else if (substr(xTabName, 1, 30-maxLength)!=substr(yTabName, 1, 30-maxLength)) {
      xColPrefix <- substr(xTabName, 1, 30-maxLength)
      yColPrefix <- substr(yTabName, 1, 30-maxLength)
    }
    else if (maxLength+1<=30) {
      xColPrefix <- 'X'
      yColPrefix <- 'Y'
    }
    else {
      stop(simpleError(paste('Too long and conflicting column names: ', 
                             paste(clash[nchar(clash)>30], sep=', '))))
    }
    clashPos <- xColNames %in% clash
    xColNames[clashPos] <- paste(xColPrefix, '_', xColNames[clashPos], sep='')
    clashPos <- yColNames %in% clash
    yColNames[clashPos] <- paste(yColPrefix, '_', yColNames[clashPos], sep='')
    
    by_x_name <- xColNames[x@cols==by_x_name]
    by_y_name <- yColNames[y@cols==by_y_name]
    xSpColNames <- xColNames[x@cols %in% xSpColNames]
    ySpColNames <- yColNames[y@cols %in% ySpColNames]
  }
  return(list(xColNames=xColNames, yColNames=yColNames, xTabName=xTabName, yTabName=yTabName,
              by_x_name=by_x_name, by_y_name=by_y_name, xSpColNames=xSpColNames, ySpColNames=ySpColNames))
}

tmpTableQuery <- function (idadf, newColNames) {
  cols <- idadf@cols
  colTerms <- c();
  for(i in 1:length(cols)) {
    if(is.null(idadf@colDefs[[cols[i]]])) {
      if (cols[i] == newColNames[i]) {
        colTerms <- c(colTerms,paste('"', cols[i],'"', sep=''))
      }
      else {
        colTerms <- c(colTerms,paste('"', cols[i],'" AS "', newColNames[i], '"', sep=''))
      }
    } 
    else {
      colTerms <- c(colTerms,paste('(',idadf@colDefs[[cols[i]]],') AS "', newColNames[i],'"', sep=''))
    }
  }
  paste("SELECT ", paste(colTerms, collapse=","), " FROM ", idadf@table,
                         ifelse((nchar(idadf@where)>0), paste(" WHERE ", idadf@where), ''), sep='')
}

makeColName <- function(baseName, suffixX, suffixY) {
  # maximum length of the column name in DB2 is 30
  res <- paste(baseName, suffixX, suffixY, sep='_')
  if (nchar(res)<=30) {
    return(res)
  }
  else {
     len <- (30-nchar(baseName))%/%2;
     suffixX <- substr(suffixX, 1, len)
     suffixY <- substr(suffixY, 1, len)
     if (suffixX != suffixY)
       return(paste(baseName, suffixX, suffixY, sep='_'))
     return(paste(baseName, 'X_Y', sep='_'))
  }
}

doubleSpColFunc.tab <- function(x, y, by.x, by.y, all.x, all.y, tableName, funcName, spName, argStr){
  checkDoubleSpInputs.tab(x, y, by.x, by.y, funcName, argStr)
  tableName <- validateTabName(tableName)
  uniNames <- resolveNameConflict(x, y, by.x, by.y)
  
  resColNames <- paste(paste('"', union(uniNames$xColNames, uniNames$yColNames), '"', sep=''), collapse=', ')
  tgtColName <- makeColName(sub('IDA', '', toupper(funcName)), uniNames$xTabName, uniNames$yTabName)
  tgtCol <- paste(spName, '("', uniNames$by_x_name, '", "', uniNames$by_y_name, '")', sep='')
  resColNames <- paste(resColNames, paste(tgtCol, ' AS "', tgtColName, '"', sep=''), sep=', ')
  commonTabs <- paste('WITH xt as (', tmpTableQuery(x, uniNames$xColNames), '), ', 
                          'yt as (', tmpTableQuery(y, uniNames$yColNames), ') ', sep='')
  spatialQuery <- paste("SELECT ", resColNames, " FROM xt, yt WHERE ", tgtCol, "=1", sep='')
                          
  if(!all.x && !all.y){
    idaQuery(paste('CREATE VIEW "', tableName, '" AS ', commonTabs, spatialQuery, sep=''))
    return(ida.data.frame(paste('"', tableName, '"', sep='')))
  }
  
  commonTabs <- paste(commonTabs, ', spt as (', spatialQuery, ') ', sep='')
  
  resColNames <- paste(paste('lt."', uniNames$xColNames, '"', collapse=', ', sep=''),
                       paste('rt."', uniNames$yColNames, '"', collapse=', ', sep=''), sep=', ')
  resColNames <- paste(resColNames, ', NVL("', tgtColName, '", 0) AS "', tgtColName, '"', sep='')
  if (all.x && !all.y) {
    lojCondition <- setdiff(uniNames$xColNames, uniNames$xSpColNames)
    lojCondition <- paste('lt."', lojCondition, '"=rt."', lojCondition, '"', collapse=' AND ', sep='')
    idaQuery(paste('CREATE VIEW "', tableName, '" AS ', commonTabs, ' SELECT ', resColNames, 
                   ' FROM xt lt LEFT OUTER JOIN spt rt ON ', lojCondition, sep=''))
  }
  else if (!all.x && all.y) {
    rojCondition <- setdiff(uniNames$yColNames, uniNames$ySpColNames)
    rojCondition <- paste('lt."', rojCondition, '"=rt."', rojCondition, '"', collapse=' AND ', sep='')
    idaQuery(paste('CREATE VIEW "', tableName, '" AS ', commonTabs, ' SELECT ', resColNames, 
                   ' FROM spt lt RIGHT OUTER JOIN yt rt ON ', rojCondition, sep=''))
  }
  else {
    lojCondition <- setdiff(uniNames$xColNames, uniNames$xSpColNames)
    lojCondition <- paste('lt."', lojCondition, '"=rt."', lojCondition, '"', collapse=' AND ', sep='')
    commonTabs <- paste(commonTabs, ', tmp as (SELECT ', resColNames, ' FROM xt lt LEFT OUTER JOIN spt rt ON ', 
                        lojCondition, ') ', sep='')
    rojCondition <- setdiff(uniNames$yColNames, uniNames$ySpColNames)
    rojCondition <- paste('lt."', rojCondition, '"=rt."', rojCondition, '"', collapse=' AND ', sep='')
    idaQuery(paste('CREATE VIEW "', tableName, '" AS ', commonTabs, ' SELECT ', resColNames, 
                   ' FROM tmp lt FULL OUTER JOIN yt rt ON ', rojCondition, sep=''))
  }
  return(ida.data.frame(paste('"', tableName, '"', sep='')))
}


doubleSpColFuncFullOutput.tab <- function(x, y, by.x, by.y, tableName, funcName, spName, argStr){
  checkDoubleSpInputs.tab(x, y, by.x, by.y, funcName, argStr) 
  tableName <- validateTabName(tableName)
  uniNames <- resolveNameConflict(x, y, by.x, by.y)
  resColNames <- paste(paste('"', union(uniNames$xColNames, uniNames$yColNames), '"', sep=''), collapse=', ')
  tgtColName <- makeColName(sub('IDA', '', toupper(funcName)), uniNames$xTabName, uniNames$yTabName)
  tgtCol <- paste(spName, '("', uniNames$by_x_name, '", "', uniNames$by_y_name, '")', sep='')
  resColNames <- paste(resColNames, paste(tgtCol, ' AS "', tgtColName, '"', sep=''), sep=', ')
  commonTabs <- paste('WITH xt as (', tmpTableQuery(x, uniNames$xColNames), '), ', 
                          'yt as (', tmpTableQuery(y, uniNames$yColNames), ') ', sep='')
  idaQuery(paste('CREATE VIEW "', tableName, '" AS ', commonTabs, "SELECT ", resColNames, " FROM xt, yt", sep=''))
  return(ida.data.frame(paste('"', tableName, '"', sep='')))
}

doubleSpColFunc <- function(x, y, by.x=NULL, by.y=NULL, all.x=FALSE, all.y=FALSE, tableName=NULL, 
                            funcName, spName, usageMsg, argStr, fullOutput=FALSE) {
  if (missing(x) || missing(y)) {
    cat(usageMsg)
    stop(simpleError(paste(funcName, ' failed: inpropriate input values.', sep='')))
  }
  else if (inherits(x,'ida.col.def') && inherits(y,'ida.col.def')) {
    return(doubleSpColFunc.col(x, y, funcName, spName, argStr))
  }
  else if (inherits(x,'ida.data.frame') && inherits(y,'ida.data.frame')) {
    if (is.null(by.x)) {
      sp_cols <- spatial.cols(x, FALSE, FALSE)
      if (length(sp_cols) > 0)
        by.x <- sp_cols[[1]]
    }
    if (is.null(by.y)) {
      sp_cols <- spatial.cols(y, FALSE, FALSE)
      if (length(sp_cols) > 0)
        by.y <- sp_cols[[1]]
    }
    if (fullOutput)
      return(doubleSpColFuncFullOutput.tab(x, y, by.x, by.y, tableName, funcName, spName, argStr))
    return(doubleSpColFunc.tab(x, y, by.x, by.y, all.x, all.y, tableName, funcName, spName, argStr))
  }
  else {
    cat(usageMsg)
    stop(simpleError(paste(funcName," failed: inpropriate input values.", sep='')))
  }
}

idaDifference <- function(x, y, by.x=NULL, by.y=NULL, tableName=NULL) {
  usageMsg <- paste('Usage:\n', 
                    '1. to calculate the difference of two geometries in the same row of an ida.data.frame, ',
                    'specify the columns which contain the geometries as inputs, ',
                    'e.g. idaDifference(<col1>, <col2>), the result is a column ',
                    'containing the difference of the geometries in each row.\n',
                    '2. to calculate the differences of the geometries in two different ida.data.frames, ',
                    'specify the ida.data.frames containing geometries as inputs, ',
                    'e.g. idaDifference(<ida.data.frame1>, <ida.data.frame2>), the result is ida.data.frame ',
                    'containing the differences of the geometries in the two ida.data.frames.\n', sep='')
  argStr <- list(x=deparse(substitute(x)), y=deparse(substitute(y)), 
               by.x=deparse(substitute(by.x)), by.y=deparse(substitute(by.y)))
  return(doubleSpColFunc(x, y, by.x, by.y, FALSE, FALSE, tableName, 'idaDifference', 'DB2GSE.ST_DIFFERENCE', 
                         usageMsg, argStr, TRUE))
}

idaUnion <- function(x, y, by.x=NULL, by.y=NULL, tableName=NULL) {
  usageMsg <- paste('Usage:\n', 
                    '1. to calculate the union of two geometries in the same row of an ida.data.frame, ', 
                    'specify the columns which contain the geometries as inputs, ',
                    'e.g. idaUnion(<col1>, <col2>), the result is a column ',
                    'containing the union of the geometries in each row.\n',
                    '2. to calculate the unions of the geometries in two different ida.data.frames, ',
                    'specify the ida.data.frames containing geometries as inputs, ',
                    'e.g. idaUnion(<ida.data.frame1>, <ida.data.frame2>), the result is an ida.data.frame ',
                    'containing the unions of the geometries in the two ida.data.frames.\n', sep='')
  argStr <- list(x=deparse(substitute(x)), y=deparse(substitute(y)), 
               by.x=deparse(substitute(by.x)), by.y=deparse(substitute(by.y)))
  return(doubleSpColFunc(x, y, by.x, by.y, FALSE, FALSE, tableName, 'idaUnion', 'DB2GSE.ST_UNION', usageMsg, argStr, TRUE))
}

idaIntersection <- function(x, y, by.x=NULL, by.y=NULL, tableName=NULL) {
  usageMsg <- paste('Usage:\n', 
                    '1. to calculate the intersection of two geometries in the same row of an ida.data.frame, ', 
                    'specify the columns which contain the geometries as inputs, ',
                    'e.g. idaIntersection(<col1>, <col2>), the result is a column ',
                    'containing the intersection of the geometries in each row.\n',
                    '2. to calculate the intersections of the geometries in two different ida.data.frames, ',
                    'specify the ida.data.frames containing geometries as inputs, ',
                    'e.g. idaIntersection(<ida.data.frame1>, <ida.data.frame2>), the result is an ida.data.frame ',
                    'containing the intersections of the geometries in the two ida.data.frames.\n', sep='')
  argStr <- list(x=deparse(substitute(x)), y=deparse(substitute(y)), 
               by.x=deparse(substitute(by.x)), by.y=deparse(substitute(by.y)))
  return(doubleSpColFunc(x, y, by.x, by.y, FALSE, FALSE, tableName, 'idaIntersection', 'DB2GSE.ST_INTERSECTION', usageMsg, argStr, TRUE))
}

idaIntersects <- function(x, y, by.x=NULL, by.y=NULL, all.x=FALSE, all.y=FALSE, tableName=NULL) {
  usageMsg <- paste('Usage:\n', 
                    '1. to calculate whether a geometry intersects another geometry in the same row of ',
                    'an ida.data.frame, specify the columns which contain the geometries as inputs, ', 
                    'e.g. idaIntersects(<col1>, <col2>), the result is a column containing the intersection relationship ', 
                    'between the geometries in each row.\n',
                    '2. to calculate whether the geometries in one ida.data.frame intersect the geometries ',
                    'in another ida.data.frame, specify the ida.data.frames containing geometries as ',
                    'inputs, e.g. idaIntersects(<ida.data.frame1>, <ida.data.frame2>), the result is an ida.data.frame ',
                    'containing the intersection relationship between the geometries in the two ida.data.frames.\n', sep='')
  argStr <- list(x=deparse(substitute(x)), y=deparse(substitute(y)), 
               by.x=deparse(substitute(by.x)), by.y=deparse(substitute(by.y)))
  return(doubleSpColFunc(x, y, by.x, by.y, all.x, all.y, tableName, 'idaIntersects', 'DB2GSE.ST_INTERSECTS', usageMsg, argStr))
}

idaMBRIntersects <- function(x, y, by.x=NULL, by.y=NULL, all.x=FALSE, all.y=FALSE, tableName=NULL) {
  usageMsg <- paste('Usage:\n', 
                    '1. to calculate whether the minimum bounding rectangle(MBR) of a geometry intersects ', 
                    'the MBR of anther geometry in the same row of an ida.data.frame, specify the columns which contain ',
                    'the geometries as inputs, e.g. idaMBRIntersects(<col1>, <col2>), the result is a column ',
                    'containing the intersection relationship between the MBRs of two geometries in each row.\n',
                    '2. to calculate whether the MBRs of the geometries in one ida.data.frame intersect the MBRs ',
                    'of the geometries in another ida.data.frame, specify the ida.data.frames containing geometries as ',
                    'inputs, e.g. idaMBRIntersects(<ida.data.frame1>, <ida.data.frame2>), the result is ida.data.frame ',
                    'containing the intersection relationship between the MBRs of the geometries ', 
                    'in the two ida.data.frames.\n', sep='')
  argStr <- list(x=deparse(substitute(x)), y=deparse(substitute(y)), 
               by.x=deparse(substitute(by.x)), by.y=deparse(substitute(by.y)))
  return(doubleSpColFunc(x, y, by.x, by.y, all.x, all.y, tableName, 'idaMBRIntersects', 'DB2GSE.ST_MBRINTERSECTS', usageMsg, argStr))
}

idaCrosses <- function(x, y, by.x=NULL, by.y=NULL, all.x=FALSE, all.y=FALSE, tableName=NULL) {
  usageMsg <- paste('Usage:\n', 
                    '1. to calculate whether a geometry crosses another geometry in the same row of ',
                    'an ida.data.frame, specify the columns which contain the geometries as inputs, ', 
                    'e.g. idaCrosses(<col1>, <col2>), the result is a column containing the cross relationship ', 
                    'between the geometries in each row.\n',
                    '2. to calculate whether the geometries in one ida.data.frame cross the geometries ',
                    'in another ida.data.frame, specify the ida.data.frames containing geometries as ',
                    'inputs, e.g. idaCrosses(<ida.data.frame1>, <ida.data.frame2>), the result is an ida.data.frame ',
                    'containing the cross relationship between the geometries in the two ida.data.frames.\n', sep='')
  argStr <- list(x=deparse(substitute(x)), y=deparse(substitute(y)), 
               by.x=deparse(substitute(by.x)), by.y=deparse(substitute(by.y)))
  return(doubleSpColFunc(x, y, by.x, by.y, all.x, all.y, tableName, 'idaCrosses', 'DB2GSE.ST_CROSSES', usageMsg, argStr))
}

idaDisjoint <- function(x, y, by.x=NULL, by.y=NULL, all.x=FALSE, all.y=FALSE, tableName=NULL) {
  usageMsg <- paste('Usage:\n', 
                    '1. to calculate whether a geometry does not intersect another geometry in the same row of ',
                    'an ida.data.frame, specify the columns which contain the geometries as inputs, ', 
                    'e.g. idaDisjoint(<col1>, <col2>), the result is a column containing the disjoint relationship ', 
                    'between the geometries in each row.\n',
                    '2. to calculate whether the geometries in one ida.data.frame do not intersect the geometries ',
                    'in another ida.data.frame, specify the ida.data.frames containing geometries as ',
                    'inputs, e.g. idaDisjoint(<ida.data.frame1>, <ida.data.frame2>), the result is an ida.data.frame ',
                    'containing the disjoint relationship between the geometries in the two ida.data.frames.\n', sep='')
  argStr <- list(x=deparse(substitute(x)), y=deparse(substitute(y)), 
               by.x=deparse(substitute(by.x)), by.y=deparse(substitute(by.y)))
  return(doubleSpColFunc(x, y, by.x, by.y, all.x, all.y, tableName, 'idaDisjoint', 'DB2GSE.ST_DISJOINT', usageMsg, argStr))
}

idaTouches <- function(x, y, by.x=NULL, by.y=NULL, all.x=FALSE, all.y=FALSE, tableName=NULL) {
  usageMsg <- paste('Usage:\n', 
                    '1. to calculate whether a geometry touches another geometry in the same row of ',
                    'an ida.data.frame, specify the columns which contain the geometries as inputs, ', 
                    'e.g. idaTouches(<col1>, <col2>), the result is a column containing the touch relationship ', 
                    'between the geometries in each row.\n',
                    '2. to calculate whether the geometries in one ida.data.frame touch the geometries ',
                    'in another ida.data.frame, specify the ida.data.frames containing geometries as ',
                    'inputs, e.g. idaTouches(<ida.data.frame1>, <ida.data.frame2>), the result is an ida.data.frame ',
                    'containing the touch relationship between the geometries in the two ida.data.frames.\n', sep='')
  argStr <- list(x=deparse(substitute(x)), y=deparse(substitute(y)), 
               by.x=deparse(substitute(by.x)), by.y=deparse(substitute(by.y)))
  return(doubleSpColFunc(x, y, by.x, by.y, all.x, all.y, tableName, 'idaTouches', 'DB2GSE.ST_TOUCHES', usageMsg, argStr))
}

idaContains <- function(x, y, by.x=NULL, by.y=NULL, all.x=FALSE, all.y=FALSE, tableName=NULL) {
  usageMsg <- paste('Usage:\n', 
                    '1. to calculate whether a geometry contains another geometry in the same row of ',
                    'an ida.data.frame, specify the columns which contain the geometries as inputs, ', 
                    'e.g. idaContains(<col1>, <col2>), the result is a column holding the containment relationship ', 
                    'between the geometries in each row.\n',
                    '2. to calculate whether the geometries in one ida.data.frame contain the geometries ',
                    'in another ida.data.frame, specify the ida.data.frames containing geometries as ',
                    'inputs, e.g. idaContains(<ida.data.frame1>, <ida.data.frame2>), the result is an ida.data.frame ',
                    'holding the containment relationship between the geometries in the two ida.data.frames.\n', sep='')
  argStr <- list(x=deparse(substitute(x)), y=deparse(substitute(y)), 
               by.x=deparse(substitute(by.x)), by.y=deparse(substitute(by.y)))
  return(doubleSpColFunc(x, y, by.x, by.y, all.x, all.y, tableName, 'idaContains', 'DB2GSE.ST_CONTAINS', usageMsg, argStr))
}

idaOverlaps <- function(x, y, by.x=NULL, by.y=NULL, all.x=FALSE, all.y=FALSE, tableName=NULL) {
  usageMsg <- paste('Usage:\n', 
                    '1. to calculate whether a geometry overlaps another geometry in the same row of ',
                    'an ida.data.frame, specify the columns which contain the geometries as inputs, ', 
                    'e.g. idaOverlaps(<col1>, <col2>), the result is a column containing the overlap relationship ',
                    'between the geometries in each row.\n',
                    '2. to calculate whether the geometries in one ida.data.frame overlap the spatial ',
                    'objects in another ida.data.frame, specify the ida.data.frames containing geometries as ',
                    'inputs, e.g. idaOverlaps(<ida.data.frame1>, <ida.data.frame2>), the result is an ida.data.frame ',
                    'containing the overlap relationship between the geometries in the two ida.data.frames.\n', sep='')
  argStr <- list(x=deparse(substitute(x)), y=deparse(substitute(y)), 
               by.x=deparse(substitute(by.x)), by.y=deparse(substitute(by.y)))
  return(doubleSpColFunc(x, y, by.x, by.y, all.x, all.y, tableName, 'idaOverlaps', 'DB2GSE.ST_OVERLAPS', usageMsg, argStr))
}

idaWithin <- function(x, y, by.x=NULL, by.y=NULL, all.x=FALSE, all.y=FALSE, tableName=NULL) {
  usageMsg <- paste('Usage:\n', 
                    '1. to calculate whether a geometry is within another geometry in the same row of ',
                    'an ida.data.frame, specify the columns which contain the geometries as inputs, ', 
                    'e.g. idaWithin(<col1>, <col2>), the result is a column containing the within relationship ',
                    'between the geometries in each row.\n',
                    '2. to calculate whether the geometries in one ida.data.frame are within the spatial ',
                    'objects in another ida.data.frame, specify the ida.data.frames containing geometries as ',
                    'inputs, e.g. idaWithin(<ida.data.frame1>, <ida.data.frame2>), the result is an ida.data.frame ',
                    'containing the within relationship between the geometries in the two ida.data.frames.\n', sep='')
  argStr <- list(x=deparse(substitute(x)), y=deparse(substitute(y)), 
               by.x=deparse(substitute(by.x)), by.y=deparse(substitute(by.y)))
  return(doubleSpColFunc(x, y, by.x, by.y, all.x, all.y, tableName, 'idaWithin', 'DB2GSE.ST_WITHIN', usageMsg, argStr))
}

idaEquals <- function(x, y, by.x=NULL, by.y=NULL, all.x=FALSE, all.y=FALSE, tableName=NULL) {
  usageMsg <- paste('Usage:\n', 
                    '1. to calculate whether a geometry is equal to another geometry in the same row of ',
                    'an ida.data.frame, specify the columns which contain the geometries as inputs, ',
                    'e.g. idaEquals(<col1>, <col2>), the result is a column containing the values indicating ',
                    'whether the geometries in the rows are equal to each other.\n',
                    '2. to calculate whether the spatial ojects in one ida.data.frame are equal to the geometries ',
                    'in another ida.data.frame, specify the ida.data.frames containing geometries as ',
                    'inputs, e.g. idaEquals(<ida.data.frame1>, <ida.data.frame2>), the result is an ida.data.frame ',
                    'containing the values indicating whether the geometries in the two ida.data.frames ',
                    'are equal to each other.\n', sep='')
  argStr <- list(x=deparse(substitute(x)), y=deparse(substitute(y)), 
               by.x=deparse(substitute(by.x)), by.y=deparse(substitute(by.y)))
  return(doubleSpColFunc(x, y, by.x, by.y, all.x, all.y, tableName, 'idaEquals', 'DB2GSE.ST_EQUALS', usageMsg, argStr))
}

distance.col <- function (x, y, unit=NULL, argStr) {
  if (!is.null(unit))
    checkDistanceUnit(unit, 'idaDistance', argStr$unit)
  checkDoubleSpInputs.col(x, y, 'idaDistance', argStr)         
  
  return(new(Class="ida.col.def", 
             term=paste('DB2GSE.ST_DISTANCE(', x@term, ', ', y@term,
             ifelse(!is.null(unit), paste(", '", unit, "'", sep=''), ''), 
             ')', sep=''),
             table=x@table, type="expr", aggType="none"));
}

distance.tab <- function(x, y, unit=NULL, by.x, by.y, tableName=NULL, argStr){
  if (!is.null(unit)) 
    checkDistanceUnit(unit, 'idaDistance', argStr$unit)
  checkDoubleSpInputs.tab(x, y, by.x, by.y, 'idaDistance', argStr)
  tableName <- validateTabName(tableName)
  uniNames <- resolveNameConflict(x, y, by.x, by.y)
    
  resColNames <- paste(paste('"', union(uniNames$xColNames, uniNames$yColNames), '"', sep=''), collapse=', ')
  distanceColName <- makeColName("DISTANCE", uniNames$xTabName, uniNames$yTabName)
  distanceCol <- paste('DB2GSE.ST_DISTANCE("', uniNames$by_x_name, '", "', uniNames$by_y_name, '"', 
                        ifelse(!is.null(unit), paste(", '", unit, "'", sep=''), ''), ')', sep='')
  resColNames <- paste(resColNames, paste(distanceCol, ' AS "', distanceColName, '"', sep=''), sep=', ')
  commonTabs <- paste('WITH xt as (', tmpTableQuery(x, uniNames$xColNames), '), ', 
                          'yt as (', tmpTableQuery(y, uniNames$yColNames), ') ', sep='')
  idaQuery(paste('CREATE VIEW "', tableName, '" AS ', commonTabs, "SELECT ", resColNames, " FROM xt, yt", sep=''))
  return(ida.data.frame(paste('"', tableName, '"', sep='')))
}

idaDistance <- function(x, y, unit=NULL, by.x=NULL, by.y=NULL, tableName=NULL){
  usageMsg <- paste('Usage:\n', 
                    '1. to calculate the distance between two geometries in the same row of an ida.data.frame, ',
                    'specify the columns which contain the geometries as inputs, e.g. idaDistance(<col1>, <col2>), ',
                    'the result is a column containing the distances between the geometries in each rows.\n',
                    '2. to calculate the distances between the geometries in two different ida.data.frames, ',
                    'specify the ida.data.frames containing geometries as inputs, ',
                    'e.g. idaDistance(<ida.data.frame1>, <ida.data.frame2>), the result is an ida.data.frame ',
                    'containing the distances between the geometries in the two ida.data.frames.\n', sep='')
  if (missing(x) || missing(y)) {
    cat(usageMsg)
    stop(simpleError('idaDistance failed: inpropriate input values.'))
  }  
  else if (inherits(x,'ida.col.def') && inherits(y,'ida.col.def')) {
    argStr <- list(x=deparse(substitute(x)), y=deparse(substitute(y)))
    return(distance.col(x, y, unit, argStr))
  }
  else if (inherits(x,'ida.data.frame') && inherits(y,'ida.data.frame')) {
    if (is.null(by.x)) {
      sp_cols <- spatial.cols(x, FALSE, FALSE)
      if (length(sp_cols) > 0)
        by.x <- sp_cols[[1]]
    }
    if (is.null(by.y)) {
      sp_cols <- spatial.cols(y, FALSE, FALSE)
      if (length(sp_cols) > 0)
        by.y <- sp_cols[[1]]
    }
    argStr <- list(x=deparse(substitute(x)), y=deparse(substitute(y)), 
                   by.x=deparse(substitute(by.x)), by.y=deparse(substitute(by.y)), 
                   unit=deparse(substitute(unit)))
    return(distance.tab(x, y, unit, by.x, by.y, tableName, argStr))
  }
  else {
    cat(usageMsg)
    stop(simpleError(paste("idaDistance failed: inpropriate input values.", sep='')))
  }
}


