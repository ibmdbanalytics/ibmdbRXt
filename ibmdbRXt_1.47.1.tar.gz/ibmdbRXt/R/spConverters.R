# 
# Copyright (c) 2010, 2014, IBM Corp. All rights reserved. 
# 		
# This program is free software: you can redistribute it and/or modify 
# it under the terms of the GNU General Public License as published by 
# the Free Software Foundation, either version 3 of the License, or 
# (at your option) any later version. 
#
# This program is distributed in the hope that it will be useful, 
# but WITHOUT ANY WARRANTY; without even the implied warranty of 
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
# GNU General Public License for more details. 
#
# You should have received a copy of the GNU General Public License 
# along with this program. If not, see <http://www.gnu.org/licenses/>. 
#


idaProj4string <- function(col){
  q <- paste("SELECT COORDSYS_NAME, COORDSYS_TYPE, ORGANIZATION,ORGANIZATION_COORDSYS_ID, ", 
              "DEFINITION FROM DB2GSE.ST_SPATIAL_REFERENCE_SYSTEMS ", 
              "WHERE SRS_ID=(SELECT db2gse.ST_SRSID(", col@term, ") FROM ", 
              col@table@table, " FETCH FIRST ROW ONLY)", sep="")
  CRSDetails<-idaQuery(q)
  if (is.null(CRSDetails) || dim(CRSDetails)[1]==0)
    stop(paste("Can not find out the coordinate reference system for the spatial column: ", col@term, sep=""));
  proj4string<-paste("+init=",CRSDetails[3],":",CRSDetails[4],sep="")
  tryCatch(crs <- CRS(proj4string), 
      error=function(e) {
        print(e); 
        stop(paste("Can not convert DB2GSE SRS to CRS{sp} for the spatial column: ", col@term, sep=""))})
  return(crs)
}

checkSpInputsForConverter <- function(idadf, col, converter) {
  if(!is.ida.data.frame(idadf))
    stop(paste("The input for the 'idadf' parameter of the '",
               converter, "' function must be an ida.data.frame object.", sep=''))
  if (is.null(col))
    stop("No spatial column was found in the input ida.data.frame.")
  if (length(idadf@cols)==0 || 
      (length(idadf@cols)==1 && idadf@cols[1]==ibmdbR:::colName(col))) {
    stop("The input ida.data.frame must contain at least one non-spatial column.");
  }
  if (!idaExistTable(idadf@table))
    stop(paste("The table or view '", idadf@table, 
               "' referred by the input ida.data.frame does not exist in the database.", sep=''))
  if(!inherits(col,'ida.col.def'))
    stop(paste("The input for 'col' parameter of the '", 
               converter, "' function must be a column of ida.data.frame.", sep=''))
  if (idadf@table != col@table@table)
    stop("The column specified by the 'col' parameter is not in the ida.data.frame specified by the 'idadf' parameter")
  if (!is.sp.col(col))
    stop("The input for 'col' parameter of the 'as.SpatialPointsDataFrame' function must be a spatial column")
}

querySpIdadf <- function (idadf, spTerm='', max.rows=NULL) {
  if (!is.ida.data.frame(idadf))
    stop(paste("Cannot query object of class: ", class(idadf)), call.=FALSE)
  if (!is.null(max.rows) && (!is.numeric(max.rows) || length(max.rows)>1 || as.integer(max.rows)!=max.rows || max.rows<1))
    stop("The input for the parameter 'max.rows' must be a positive integer number or NULL.", call.=FALSE)
    
  spColNames <- spatial.cols(idadf, TRUE, FALSE)
  colNames <- idadf@cols
  colTerms <- character(0)
  for(colName in colNames) {
    if (colName %in% spColNames) 
      next
    else if(is.null(idadf@colDefs[[colName]])) 
      colTerms <- c(colTerms, paste('"', colName, '"', sep=''))
    else 
      colTerms <- c(colTerms, paste('(', idadf@colDefs[[colName]], ') AS "', colName, '"', sep=''))
  }
  colTerms <- c(colTerms, spTerm)
  
  res = idaQuery(paste("SELECT ", paste( colTerms, collapse=","), " FROM ", idadf@table,
                    ifelse((nchar(idadf@where)>0), paste(" WHERE ", idadf@where), ""),
                    ifelse(is.null(max.rows), "", paste(" FETCH FIRST ", max.rows, " ROWS ONLY")),
                    sep=''))
  return(res)
}

as.SpatialPointsDataFrame <- function(idadf, col=NULL, max.rows=NULL){
  if (is.null(col)) {
    sp_cols <- spatial.cols(idadf, FALSE, FALSE)
    if (length(sp_cols) > 0)
      col <- sp_cols[[1]]
  }
  checkSpInputsForConverter(idadf, col, 'as.SpatialPointsDataFrame')
  colSpType <- sp.type(col)
  if(colSpType!="ST_POINT")
    stop(paste("as.SpatialPointsDataFrame cannot be applied to the spatial column of type '", colSpType, 
       "'. Use an appropriate transformation function, the candidates are: as.SpatialLinesDataFrame, as.SpatialPolygonsDataFrame"))

  proj4string <- idaProj4string(col)  
  spTerm <- paste("db2gse.ST_X(", col@term, ") AS X, db2gse.ST_Y(", col@term, ") AS Y", sep='') 
  data <- querySpIdadf(idadf, spTerm=spTerm, max.rows=max.rows)
  colCount <- ncol(data)
  coords <- as.matrix(data[,c(colCount-1, colCount)])
  data[[colCount]] <- NULL
  data[[colCount-1]] <- NULL
  coord.nrs <- numeric(0)
  frame<-SpatialPointsDataFrame(coords, data, coords.nrs = coord.nrs, 
                                proj4string = proj4string, match.ID = TRUE)
  return(frame)
}

parseLine <- function(line){
  l<-gsub(')', '', line, fixed=TRUE)
  l<-gsub('(', '', l, fixed=TRUE)
  l<-gsub(', ', ',', l, fixed=TRUE)
  l<-gsub(' ', ',', l, fixed=TRUE)
  l<-strsplit(l, ',')
  l<-unlist(l)
  l<-as.numeric(l)
  l<-matrix(l, ncol=2, byrow=T)
  return(l)
}

parseMultiline <- function(multilineAsText, id){ 
  if (grepl('MULTILINESTRING EMPTY', multilineAsText, fixed=TRUE) || # Empty multistring 
      !grepl('))$', multilineAsText) ) # WKT too long and get truncated, multistring incomplete
      return(NULL)
  multilineAsText <- sub('MULTILINESTRING ', '', multilineAsText, fixed=TRUE)
  lines <- unlist(strsplit(multilineAsText, ',(', fixed=TRUE))
  lineCoords <- lapply(lines, parseLine)
  
  slinelist <- c()
  for(i in 1:length(lineCoords)){
    slinelist<-c(slinelist, Line(lineCoords[[i]]))
  }
  lines <- Lines(slinelist, as.character(id))
  return(lines)  
}

parsePolygon <- function(polygon){ 
  p <- gsub(')', '', polygon, fixed=TRUE)
  p <- gsub('(', '', p, fixed=TRUE)
  p <- gsub(', ', ',', p, fixed=TRUE)
  p <- gsub(' ', ',', p, fixed=TRUE)
  p <- strsplit(p, ',')
  p <- unlist(p)
  p <- as.numeric(p)
  p <- matrix(p, ncol=2, byrow=T)
  return(p)
}

parseMultiPolygon <- function(multipolygonAsText, id){
  if (grepl('MULTIPOLYGON EMPTY', multipolygonAsText, fixed=TRUE) || # Empty multipolygon 
      !grepl(')))$', multipolygonAsText) ) # WKT too long and get truncated, multipolygon incomplete
      return(NULL)
  multipolygonAsText <- sub('MULTIPOLYGON ', '', multipolygonAsText, fixed=TRUE)
  plist <- unlist(strsplit(multipolygonAsText, ',(', fixed=TRUE))
  polygonCoords <- lapply(plist, parsePolygon)
  
  srl <- c()
  for(i in 1:length(polygonCoords)){
    srl <- c(srl, Polygon(polygonCoords[[i]]))
  }
  polygons <- Polygons(srl, as.character(id))
  return(polygons)
}

parseGeometries <- function(geometryStrings, funcName) {
  geometries <- c()
  errIndex <- c()
  parseGeometry <- ifelse(funcName=='as.SpatialLinesDataFrame', parseMultiline, parseMultiPolygon)
  for (i in 1:length(geometryStrings)) {
    geometry <- NULL;
    try({geometry <- parseGeometry(geometryStrings[i], as.character(i))},silent=TRUE);
    if(!is.null(geometry)) {
      geometries <- c(geometries, geometry)
    }
    else 
      errIndex <- c(errIndex, i)
  }
  return(list(geometries=geometries, errIndex=errIndex))
}

as.SpatialGeometryDataFrame <- function(idadf, col=NULL, max.rows=NULL, funcName){
  if (is.null(col)) {
    sp_cols <- spatial.cols(idadf, FALSE, FALSE)
    if (length(sp_cols) > 0)
      col <- sp_cols[[1]]
  }
  checkSpInputsForConverter(idadf, col, funcName)
  colSpType <- sp.type(col)
  if(funcName=='as.SpatialLinesDataFrame' && colSpType!="ST_MULTILINESTRING") {
    stop(paste("as.SpatialLinesDataFrame cannot be applied to the spatial column of type '", colSpType, 
       "'. Use an appropriate transformation function, the candidates are: as.SpatialPointsDataFrame, as.SpatialPolygonsDataFrame"), call.=FALSE)
  }
  else if(funcName=='as.SpatialPolygonsDataFrame' && colSpType!="ST_MULTIPOLYGON") {
    stop(paste("as.SpatialPolygonsDataFrame cannot be applied to the spatial column of type '", colSpType, 
       "'. Use an appropriate transformation function, the candidates are: as.SpatialPointsDataFrame, as.SpatialLinesDataFrame"), call.=FALSE)
  }

  proj4string <- idaProj4string(col)
  data <- querySpIdadf(idadf, paste('DB2GSE.ST_AsText(', col@term, ')', sep=''), max.rows)
  colCount <- ncol(data)
  geometryStrings <- data[,colCount]
  
  parseRes <- parseGeometries(geometryStrings, funcName)
  errIndex <- parseRes$errIndex
  errCount <- length(errIndex)
  if (errCount > 0)
    failedRows <- data[errIndex,]
  rowCount <- length(geometryStrings)

  data[[colCount]] <- NULL
  if (errCount==rowCount) {
    stop(paste(funcName, ' failed: none of the ', rowCount, ' rows in the input ida.data.frame ',
               'could be successfully converted.'))
  }
  else if (errCount>0) {
    validIndex <- setdiff(1:rowCount, errIndex)
    if (length(data)==1) {
      data <- data.frame(data=data[validIndex, 1])
      rownames(data) <- validIndex
    }
    else {
      data <- data[validIndex,]
    }
    warning(paste(errCount, ' out of ', rowCount, ' rows failed to be converted. ',
                  "You can retrieve the failed rows from the returned value with the command:  ",
                  "attr(<return_value>, 'failed.rows')", sep=''), call.=FALSE)        
  }
  
  geometries <- parseRes$geometries
  if (funcName == 'as.SpatialLinesDataFrame') {
    spatialLines <- SpatialLines(geometries, proj4string)
    spdf <- SpatialLinesDataFrame(spatialLines, data)
  }
  else {  # as.SpatialPolygonsDataFrame
    spatialPolygons <- SpatialPolygons(Srl=geometries, proj4string=proj4string)
  	spdf <- SpatialPolygonsDataFrame(spatialPolygons, data)
  }
  if (errCount > 0) {
    attr(spdf, 'failed.rows') <- failedRows
  }
  return(spdf)
}


as.SpatialLinesDataFrame <- function(idadf, col=NULL, max.rows=NULL){
  return(as.SpatialGeometryDataFrame(idadf, col, max.rows, 'as.SpatialLinesDataFrame'))
}


as.SpatialPolygonsDataFrame <- function(idadf, col=NULL, max.rows=NULL){
  return(as.SpatialGeometryDataFrame(idadf, col, max.rows, 'as.SpatialPolygonsDataFrame'))
}

