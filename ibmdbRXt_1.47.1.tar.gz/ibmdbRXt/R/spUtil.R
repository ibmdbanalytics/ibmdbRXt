# 
# Copyright (c) 2010, 2014, IBM Corp. All rights reserved. 
# 		
# This program is free software: you can redistribute it and/or modify 
# it under the terms of the GNU General Public License as published by 
# the Free Software Foundation, either version 3 of the License, or 
# (at your option) any later version. 
#
# This program is distributed in the hope that it will be useful, 
# but WITHOUT ANY WARRANTY; without even the implied warranty of 
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
# GNU General Public License for more details. 
#
# You should have received a copy of the GNU General Public License 
# along with this program. If not, see <http://www.gnu.org/licenses/>. 
#

spatial.cols <- function (idadf, nameOnly=FALSE, checkDF=TRUE) {
  if(!inherits(idadf, "ida.data.frame"))
    stop("The function 'spatial.cols' can only be applied to ida.data.frame object.")
  tableName <- idadf@table
  if(checkDF && !idaExistTable(tableName)) {
    stop("Table '", tableName, "' for the input ida.data.frame does not exist in the database");
  }
  return(c(ex.spatial.cols(idadf, nameOnly), def.spatial.cols(idadf, nameOnly)))
}

ex.spatial.cols <- function (idadf, nameOnly=FALSE) {
  tableName <- ibmdbR:::parseTableName(idadf@table)$table;
  spatialCol<- idaQuery(" SELECT COLNAME,TYPENAME FROM SYSCAT.COLUMNS WHERE TABNAME LIKE '", tableName, 
  						"' AND TYPENAME LIKE 'ST_%' ORDER BY COLNO") 
  #original columns in the table/view, might be removed from ida.data.frame
  spColNames <- intersect(spatialCol[[1]], idadf@cols)
  if(length(spColNames)==0) {
    if (nameOnly)
      return(character(0))
    return(list())
  }
  if (nameOnly)
    return(spColNames)
  spaCols <- list()
  for(i in 1:length(spColNames)) {
    spaCols[[spColNames[i]]] <- new(Class="ida.col.def", term=paste('"',spColNames[i],'"',sep=''), 
                       table=idadf, type="spatialColumn", aggType="none")
  }
  return(spaCols)
}

def.spatial.cols <- function(idadf, nameOnly=FALSE) {
  if (is.null(idadf@colDefs) || length(idadf@colDefs)==0) {
    if (nameOnly)
      return(character(0))
    return(list())
  }
  # the return type of the expression in which the leftmost spatial function returns a spatial type 
  # is a spatial type
  spFuncsRtSpVal <- idaQuery("select distinct f.NAME  from SYSIBM.SYSFUNCTIONS f, sysibm.SYSDATATYPES t ",  
                             "where f.name like 'ST_%' and f.RETURN_TYPE=t.TYPEID and t.name like 'ST_%'")
  spFuncsRtSpVal <- spFuncsRtSpVal[[1]]
  colDefs <- idadf@colDefs
  defColNames <- intersect(names(colDefs), idadf@cols)
  defSpColNames <- c()
  for (colName in defColNames) {
    colTerm <- toupper(colDefs[colName])
    pos <- regexpr('ST_[a-zA-Z]+', colTerm)
    if (pos != -1) {
      spFuncName <- substr(colTerm, pos, pos+attr(pos, "match.length")-1)
      if (spFuncName %in% spFuncsRtSpVal)
        defSpColNames <- c(defSpColNames, colName)
    }
  }
  if (length(defSpColNames) == 0) {
    if (nameOnly)
      return(character(0))
    return(list())
  }
  if (nameOnly)
    return(defSpColNames)
  defSpCols <- list()
  for(i in 1:length(defSpColNames)) {
    defSpCols[[defSpColNames[i]]] <- new(Class="ida.col.def", term=colDefs[[defSpColNames[i]]], 
                          table=idadf, type="spatialExpr", aggType="none");
  }
  return(defSpCols)
}

is.sp.col <- function(colDef) {
  if(!inherits(colDef, "ida.col.def"))
    stop("The function 'is.sp.col' can only be applied to ida.col.def object.")
  if (grepl('spatial', colDef@type))
    return(TRUE)
  return(!is.null(sp.type(colDef)))
}

sp.type <- function(colDef) {
  if (!inherits(colDef, "ida.col.def")) 
    stop("The function 'sp.type' can only be applied to an ida.col.def object.")
  
  if (colDef@type=='column' || colDef@type=='spatialColumn') {
    tabName <- colDef@table@table
    tabName <- ibmdbR:::parseTableName(tabName)
    spatialType <- idaQuery("SELECT TYPENAME FROM SYSCAT.COLUMNS WHERE TABNAME= '", tabName$table,
    						"' AND TABSCHEMA='", tabName$schema, "' AND COLNAME='", ibmdbR:::removeQuotes(colDef@term), 
    						"' AND TYPENAME LIKE 'ST_%'")
    spatialType <- spatialType[[1]]
    if (length(spatialType)>0)
      return(spatialType)
  }
  else if (colDef@type=='expr' || colDef@type=='spatialExpr') {
    spFuncsRtSpVal <- idaQuery("select distinct f.NAME, t.name  from SYSIBM.SYSFUNCTIONS f, sysibm.SYSDATATYPES t ",  
                               "where f.name like 'ST_%' and f.RETURN_TYPE=t.TYPEID and t.name like 'ST_%'")
    funcNameType <- list()
    for (i in 1:nrow(spFuncsRtSpVal)) {
      funcNameType[[spFuncsRtSpVal[i, 1]]] <- spFuncsRtSpVal[i, 2]
    }
    spFuncsRtSpVal <- spFuncsRtSpVal[[1]]
    colTerm <- toupper(colDef@term)
    pos <- regexpr('ST_[a-zA-Z]+', colTerm)
    if (pos != -1) {
      spFuncName <- substr(colTerm, pos, pos+attr(pos, "match.length")-1)
      return(funcNameType[[spFuncName]])
    }
  }
}

normalizeDBName <- function(dbName) {
  res <- ibmdbR:::removeQuotes(dbName)
  if (res != dbName) {
    if (toupper(res) != res)
      res <-dbName
  }
  else {
    res <- toupper(dbName)
  }
  return(res)
}

idaShowSRS <- function(all.info=FALSE) {
  columns <- ifelse(all.info, '*', 'SRS_NAME, SRS_ID, COORDSYS_NAME, X_OFFSET, X_SCALE, Y_OFFSET, Z_OFFSET, Z_SCALE, M_OFFSET, M_SCALE')
  res <- idaQuery(paste('select', columns, 'from db2gse.ST_SPATIAL_REFERENCE_SYSTEMS'))
  return(res)
}

idaSrsId <- function(x) {
  if (is.character(x)) {
    x <- ida.data.frame(x[1])
  }
  if (inherits(x,'ida.data.frame')) {
    cols <- spatial.cols(x, FALSE, FALSE)
    if (length(cols) == 0)
      stop(simpleError(paste("The table or view '", x@table, "' referred by the input ida.data.frame does not contain spatial column.", sep='')))
    x <- cols[[1]]
  }
  else if (!inherits(x, 'ida.col.def')) {
      stop(simpleError(paste('Inpropriate input value. The input value must be either the name of a database table, ', 
                              'an ida.data.frame or a column of an ida.data.frame', sep='')))
  }
  else if (!is.sp.col(x)) {
      stop(simpleError(paste("The input column '", ibmdbR:::colName(x), "' does not contain spatial data.", sep='')))
  }
  srsid <- idaScalarQuery(paste('select db2gse.ST_SrsId(', x@term, ') from ', x@table@table, ' fetch first row only', sep=''))
  return(srsid)
}

idaPoint <- function(x, srsId=0) {
  if (!is.list(x) || length(x)!=2 || !inherits(x[[1]], 'ida.col.def') || !inherits(x[[2]], 'ida.col.def')) 
    stop(simpleError(paste("Inpropriate input value for the argument 'x'. The input value must be a list of two columns of ", 
                           "the same ida.data.frame.", sep='')))
  x_coord <- x[[1]]
  y_coord <- x[[2]]
  if (x_coord@table@table != y_coord@table@table) 
    stop(simpleError(paste("The input columns '", ibmdbR:::colName(x_coord), "' and '", ibmdbR:::colName(y_coord), 
                           "' are not in the same ida.data.frame.", sep='')))
  if (!is.numeric(srsId) || length(srsId) > 1) 
    stop(simpleError(paste("Inpropriate input value for the argument 'srsId'. The input value must be a single positive integer.")))
  srs <- idaShowSRS()
  if (!(srsId %in% srs$SRS_ID))
    stop(simpleError(paste("The SRS id specified by 'srsId' is invalid. Check the SRS in the system with the function 'idaShowSRS()'.")))
  return(new(Class="ida.col.def", 
             term=paste('db2gse.ST_Point(', x_coord@term, ', ', y_coord@term, ', ', srsId, ')', sep=''), 
             table=x_coord@table, type="spatialExpr", aggType="none"));
}

getDistanceUnits <- function() {
  res <- idaQuery("select unit_name from DB2GSE.ST_UNITS_OF_MEASURE where unit_type='LINEAR' order by length(unit_name), unit_name")
  return(as.vector(res[[1]]))
}

checkDistanceUnit <- function(unit, funcName, parmUnit) {
  distanceUnits <- getDistanceUnits()
  options("warning.length"=2000)
  if (!is.character(unit) || length(unit)!=1)
    stop(simpleError(paste(funcName, " failed: the input value '", parmUnit, "' for the distance unit is not a character value. ", 
    "The supported distance units (case-insensitive) are :", paste("'", distanceUnits, "'", collapse=', ', sep=''), '.', sep='')))
  unit <- toupper(unit)
  if (!(unit %in% distanceUnits)) {
    stop(simpleError(paste(funcName, " failed: the input distance unit '", unit, "' is invalid. The supported distance units (case-insensitive) are :",
               paste("'", distanceUnits, "'", collapse=', ', sep=''), '.', sep='')))
  }
} 
