# 
# Copyright (c) 2010, 2014, IBM Corp. All rights reserved. 
# 		
# This program is free software: you can redistribute it and/or modify 
# it under the terms of the GNU General Public License as published by 
# the Free Software Foundation, either version 3 of the License, or 
# (at your option) any later version. 
#
# This program is distributed in the hope that it will be useful, 
# but WITHOUT ANY WARRANTY; without even the implied warranty of 
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
# GNU General Public License for more details. 
#
# You should have received a copy of the GNU General Public License 
# along with this program. If not, see <http://www.gnu.org/licenses/>. 
#

validateSingleSpInput <- function(x, funcName, xStr='') {
  if (missing(x) || (!inherits(x,'ida.data.frame')&&!inherits(x,'ida.col.def'))) { 
    cat(paste('Usage:\n', funcName, " can only be applied to an ida.data.frame ",
               "or a spatial column in ida.data.frame, e.g. ", 
               funcName, '(<ida.data.frame>), or ', funcName, '(<col>).\n', sep=''))
    stop(simpleError(paste(funcName, ' failed: inpropriate input values.', sep='')))
  }
  tabName <- ifelse(inherits(x,'ida.data.frame'), x@table, x@table@table)
  if (!idaExistTable(tabName))
    stop(simpleError(paste(funcName, " failed: the table or view'", tabName, 
               "' referred by the input ida.data.frame does not exist in the database.", spe='')))
  if (inherits(x,'ida.data.frame')) {
    cols <- spatial.cols(x, FALSE, FALSE)
    if (length(cols) == 0)
      stop(simpleError(paste(funcName, " failed: no spatial column was found in the ida.data.frame '", 
                 xStr, "'",sep='')))
    cat(paste(funcName, " is applied on the spatial column '", names(cols)[1], 
                  "' of the input ida.data.frame '", xStr, "'\n", sep=''))
    return(cols[[1]])
  }
  if (!is.sp.col(x)) {
    colName <- ibmdbR:::colName(x)
    if (is.null(colName))
    	colName <- x@term 
    stop(simpleError(paste("'", funcName, "' can not be applied on non-spatial column '", colName, "'", sep='')))
  }
  return(x)
}

singleSpColFunc <- function (x, funcName, spName, isRetTypeSp, unit=NULL, xStr) {
  x <- validateSingleSpInput(x, funcName, xStr)
  if (!is.null(unit))
    checkDistanceUnit(unit, funcName)
  type <- ifelse(isRetTypeSp, 'spatialExpr', 'expr')
  return(new(Class="ida.col.def", 
             term=paste(spName, '(', x@term, 
             ifelse(!is.null(unit), paste(", '", unit, "'", sep=''), ''),
             ')', sep=''), 
             table=x@table, type=type, aggType="none"));
}

idaArea <- function (x, unit=NULL) {
  return(singleSpColFunc(x, 'idaArea', 'DB2GSE.ST_Area', FALSE, unit, deparse(substitute(x))))
}

idaLength <- function (x, unit=NULL) {
  x <- validateSingleSpInput(x, 'idaLength', deparse(substitute(x)))
  if (!is.null(unit))
    checkDistanceUnit(unit, 'idaLength')
  spType <- toupper(sp.type(x))
  term <- ifelse(spType=='ST_LINESTRING'||spType=='ST_MULTILINESTRING',  x@term, 
                 paste('DB2GSE.ST_ToMultiLine(', x@term, ')', sep=''))
  return(new(Class="ida.col.def", 
             term=paste('DB2GSE.ST_Length', '(', term, 
             ifelse(!is.null(unit), paste(", '", unit, "'", sep=''), ''),
             ')', sep=''), 
             table=x@table, type='expr', aggType="none"));
}

idaCentroid <- function (x) {
  return(singleSpColFunc(x, 'idaCentroid', 'DB2GSE.ST_Centroid', TRUE, NULL, deparse(substitute(x))))
}

idaIsSimple <- function (x) {
  return(singleSpColFunc(x, 'idaIsSimple', 'DB2GSE.ST_IsSimple', FALSE, NULL, deparse(substitute(x))))
}

idaIsValid <- function (x) {
  return(singleSpColFunc(x, 'idaIsValid', 'DB2GSE.ST_IsValid', FALSE, NULL, deparse(substitute(x))))
}

idaIsEmpty <- function (x) {
  return(singleSpColFunc(x, 'idaIsEmpty', 'DB2GSE.ST_IsEmpty', FALSE, NULL, deparse(substitute(x))))
}

idaBoundary <- function (x) {
  return(singleSpColFunc(x, 'idaBoundary', 'DB2GSE.ST_Boundary', TRUE, NULL, deparse(substitute(x))))
}

idaDimension <- function (x) {
  return(singleSpColFunc(x, 'idaDimension', 'DB2GSE.ST_Dimension', FALSE, NULL, deparse(substitute(x))))
}

idaEnvelope <- function (x) {
  return(singleSpColFunc(x, 'idaEnvelope', 'DB2GSE.ST_Envelope', TRUE, NULL, deparse(substitute(x))))
}

idaMBR <- function (x) {
  return(singleSpColFunc(x, 'idaMBR', 'DB2GSE.ST_MBR', TRUE, NULL, deparse(substitute(x))))
}

idaToMultiLine <- function (x) {
  return(singleSpColFunc(x, 'idaToMultiLine', 'DB2GSE.ST_ToMultiLine', TRUE, NULL, deparse(substitute(x))))
}

idaToMultiPolygon <- function (x) {
  return(singleSpColFunc(x, 'idaToMultiPolygon', 'DB2GSE.ST_ToMultiPolygon', TRUE, NULL, deparse(substitute(x))))
}

idaBuffer <- function (x, distance, unit=NULL) {
  x <- validateSingleSpInput(x, 'idaBuffer',  deparse(substitute(x)))
  if (missing(distance)) 
    stop("idaBuffer failed: the input for the parameter 'distance' is missing.")
  else if (!is.numeric(distance) || length(distance)!=1)
    stop("idaBuffer failed: the input for the parameter 'distance' must be a number.")
  if (!is.null(unit))
    checkDistanceUnit(unit, 'idaBuffer')
  
  return(new(Class="ida.col.def", 
             term=paste('db2gse.ST_BUFFER(', x@term, ', ', distance,
                        ifelse(!is.null(unit), paste(", '", unit, "'", sep=''), ''), 
                        ')', sep=''),
             table=x@table, type="spatialExpr", aggType="none"));
}
